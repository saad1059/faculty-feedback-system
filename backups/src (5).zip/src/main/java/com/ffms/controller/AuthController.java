
package com.ffms.controller;

import com.ffms.model.Faculty;
import com.ffms.model.Student;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class AuthController {

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/faculty/register")
    public String showFacultyRegistrationForm(Model model) {
        model.addAttribute("faculty", new Faculty());
        return "faculty_register";
    }

    @PostMapping("/faculty/register")
    public String registerFaculty(@ModelAttribute Faculty faculty) {
        System.out.println("Faculty Registered: " + faculty.getName());
        return "redirect:/faculty/login";
    }

    @GetMapping("/faculty/login")
    public String showFacultyLoginForm(Model model) {
        model.addAttribute("faculty", new Faculty());
        return "faculty_login";
    }

    @PostMapping("/faculty/login")
    public String loginFaculty(@ModelAttribute Faculty faculty) {
        System.out.println("Faculty Login Attempted: " + faculty.getEmail());
        return "faculty_dashboard";
    }

    @GetMapping("/student/register")
    public String showStudentRegistrationForm(Model model) {
        model.addAttribute("student", new Student());
        return "student_register";
    }

    @PostMapping("/student/register")
    public String registerStudent(@ModelAttribute Student student) {
        System.out.println("Student Registered: " + student.getName());
        return "redirect:/student/login";
    }

    @GetMapping("/student/login")
    public String showStudentLoginForm(Model model) {
        model.addAttribute("student", new Student());
        return "student_login";
    }

    @PostMapping("/student/login")
    public String loginStudent(@ModelAttribute Student student) {
        System.out.println("Student Login Attempted: " + student.getEmail());
        return "student_dashboard";
    }

    @GetMapping("/faculty/dashboard")
    public String facultyDashboard() {
        return "faculty_dashboard";
    }

    @GetMapping("/student/dashboard")
    public String studentDashboard() {
        return "student_dashboard";
    }
}
