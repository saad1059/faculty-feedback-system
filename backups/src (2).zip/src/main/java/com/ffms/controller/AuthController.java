package com.ffms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ffms.model.Faculty;
import com.ffms.model.Student;

@Controller
@RequestMapping
public class AuthController {

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/faculty/register")
    public String facultyRegisterForm(Model model) {
        model.addAttribute("faculty", new Faculty());
        return "faculty_register";
    }

    @GetMapping("/faculty/login")
    public String facultyLoginForm(Model model) {
        model.addAttribute("faculty", new Faculty());
        return "faculty_login";
    }

    @GetMapping("/student/register")
    public String studentRegisterForm(Model model) {
        model.addAttribute("student", new Student());
        return "student_register";
    }

    @GetMapping("/student/login")
    public String studentLoginForm(Model model) {
        model.addAttribute("student", new Student());
        return "student_login";
    }
}
