
package com.ffms.controller;

import com.ffms.model.Faculty;
import com.ffms.model.Student;
import com.ffms.repository.FacultyRepository;
import com.ffms.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private FacultyRepository facultyRepository;

    @Autowired
    private StudentRepository studentRepository;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/register")
    public String showFacultyForm(Model model) {
        model.addAttribute("faculty", new Faculty());
        return "register";
    }

    @PostMapping("/register")
    public String registerFaculty(@ModelAttribute Faculty faculty) {
        facultyRepository.save(faculty);
        return "redirect:/";
    }

    @GetMapping("/student-login")
    public String showStudentLoginForm(Model model) {
        model.addAttribute("student", new Student());
        return "student-login";
    }

    @PostMapping("/student-login")
    public String loginStudent(@ModelAttribute Student student, Model model) {
        Student dbStudent = studentRepository.findByEmail(student.getEmail());
        if (dbStudent != null && dbStudent.getPassword().equals(student.getPassword())) {
            return "redirect:/";
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "student-login";
        }
    }
}
